import qrcode
import os

img = qrcode.make("Thanks for watching video.") #Generates the QR Code
img.save('qr.png',"PNG") # Save as a image

os.startfile('qr.png') # Opens the Image
